// 実際のバージョン定義 (自動生成されるので以下を編集しない)
const nakoVersion = {
    version: '3.7.19',
    major: 3,
    minor: 7,
    patch: 19
};
export default nakoVersion;
