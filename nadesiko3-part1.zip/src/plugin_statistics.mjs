const PluginStatistics = {
    'meta': {
        type: 'const',
        value: {
            pluginName: 'plugin_statistics',
            description: '統計分析機能を提供するプラグイン | Statistical analysis functionality',
            pluginVersion: '1.0.0',
            nakoRuntime: ['cnako', 'wnako'],
            nakoVersion: '3.6.0'
        }
    },
    // === 記述統計 ===
    '基本統計量': {
        type: 'func',
        josi: [['の']],
        pure: true,
        fn: function (data) {
            if (!Array.isArray(data) || data.length === 0) {
                return { count: 0, mean: 0, median: 0, mode: [], std: 0, variance: 0, min: 0, max: 0 };
            }
            const sorted = [...data].sort((a, b) => a - b);
            const n = data.length;
            const sum = data.reduce((acc, val) => acc + val, 0);
            const mean = sum / n;
            // 中央値
            const median = n % 2 === 0
                ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2
                : sorted[Math.floor(n / 2)];
            // 最頻値
            const frequency = {};
            data.forEach((val) => { frequency[String(val)] = (frequency[String(val)] || 0) + 1; });
            const maxFreq = Math.max(...Object.values(frequency));
            const mode = Object.keys(frequency).filter((key) => frequency[key] === maxFreq).map(Number);
            // 分散と標準偏差
            const variance = data.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / n;
            const std = Math.sqrt(variance);
            return {
                count: n,
                mean: mean,
                median: median,
                mode: mode,
                std: std,
                variance: variance,
                min: Math.min(...data),
                max: Math.max(...data)
            };
        }
    },
    '四分位範囲': {
        type: 'func',
        josi: [['の']],
        pure: true,
        fn: function (data) {
            if (!Array.isArray(data) || data.length === 0)
                return { q1: 0, q2: 0, q3: 0, iqr: 0 };
            const sorted = [...data].sort((a, b) => a - b);
            const n = sorted.length;
            const quartile = (arr, q) => {
                const pos = (n - 1) * q;
                const base = Math.floor(pos);
                const rest = pos - base;
                if (arr[base + 1] !== undefined) {
                    return arr[base] + rest * (arr[base + 1] - arr[base]);
                }
                else {
                    return arr[base];
                }
            };
            const q1 = quartile(sorted, 0.25);
            const q2 = quartile(sorted, 0.5);
            const q3 = quartile(sorted, 0.75);
            const iqr = q3 - q1;
            return { q1, q2, q3, iqr };
        }
    },
    // === 確率分布 ===
    '正規分布確率': {
        type: 'func',
        josi: [['で'], ['の']],
        pure: true,
        fn: function (x, mean = 0, std = 1) {
            const coefficient = 1 / (std * Math.sqrt(2 * Math.PI));
            const exponent = -Math.pow(x - mean, 2) / (2 * Math.pow(std, 2));
            return coefficient * Math.exp(exponent);
        }
    },
    '二項分布確率': {
        type: 'func',
        josi: [['で'], ['の'], ['回']],
        pure: true,
        fn: function (n, k, p) {
            if (k > n || k < 0)
                return 0;
            // 二項係数の計算
            const binomialCoefficient = (n, k) => {
                if (k > n - k)
                    k = n - k;
                let result = 1;
                for (let i = 0; i < k; i++) {
                    result = result * (n - i) / (i + 1);
                }
                return result;
            };
            return binomialCoefficient(n, k) * Math.pow(p, k) * Math.pow(1 - p, n - k);
        }
    },
    'ポアソン分布確率': {
        type: 'func',
        josi: [['で'], ['の']],
        pure: true,
        fn: function (k, lambda) {
            if (k < 0)
                return 0;
            const frequency = {};
            const factorial = (n) => {
                if (n <= 1)
                    return 1;
                return n * factorial(n - 1);
            };
            return Math.pow(lambda, k) * Math.exp(-lambda) / factorial(k);
        }
    },
    // === 仮説検定 ===
    't検定': {
        type: 'func',
        josi: [['と'], ['で']],
        pure: true,
        fn: function (sample1, sample2, alpha = 0.05) {
            if (!Array.isArray(sample1) || !Array.isArray(sample2) ||
                sample1.length === 0 || sample2.length === 0) {
                return { tStat: 0, pValue: 1, significant: false };
            }
            const n1 = sample1.length;
            const n2 = sample2.length;
            const mean1 = sample1.reduce((a, b) => a + b) / n1;
            const mean2 = sample2.reduce((a, b) => a + b) / n2;
            const var1 = sample1.reduce((acc, val) => acc + Math.pow(val - mean1, 2), 0) / (n1 - 1);
            const var2 = sample2.reduce((acc, val) => acc + Math.pow(val - mean2, 2), 0) / (n2 - 1);
            const pooledVariance = ((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2);
            const standardError = Math.sqrt(pooledVariance * (1 / n1 + 1 / n2));
            const tStat = (mean1 - mean2) / standardError;
            const df = n1 + n2 - 2;
            // 簡易的なp値計算（実際にはt分布表が必要）
            const pValue = 2 * (1 - PluginStatistics._tCDF(Math.abs(tStat), df));
            return {
                tStat: tStat,
                pValue: pValue,
                significant: pValue < alpha,
                degreesOfFreedom: df
            };
        }
    },
    'カイ二乗検定': {
        type: 'func',
        josi: [['と']],
        pure: true,
        fn: function (observed, expected) {
            if (!Array.isArray(observed) || !Array.isArray(expected) ||
                observed.length !== expected.length) {
                return { chiSquare: 0, pValue: 1, significant: false };
            }
            const chiSquare = observed.reduce((sum, obs, i) => {
                const exp = expected[i];
                return sum + Math.pow(obs - exp, 2) / exp;
            }, 0);
            const df = observed.length - 1;
            const pValue = 1 - PluginStatistics._chiSquareCDF(chiSquare, df);
            return {
                chiSquare: chiSquare,
                pValue: pValue,
                significant: pValue < 0.05,
                degreesOfFreedom: df
            };
        }
    },
    // === ヘルパー関数 ===
    '_tCDF': function (t, df) {
        // 簡易的なt分布の累積分布関数
        // 実際にはもっと複雑な計算が必要
        return 0.5 + 0.5 * Math.sign(t) * Math.sqrt(1 - Math.exp(-2 * t * t / df));
    },
    '_chiSquareCDF': function (x, df) {
        // 簡易的なカイ二乗分布の累積分布関数
        // 実際にはガンマ関数が必要
        if (x <= 0)
            return 0;
        return 1 - Math.exp(-x / 2);
    }
};
// プラグイン登録
if (typeof window !== 'undefined') {
    window.PluginStatistics = PluginStatistics;
}
else if (typeof global !== 'undefined') {
    global.PluginStatistics = PluginStatistics;
}
export default PluginStatistics;
