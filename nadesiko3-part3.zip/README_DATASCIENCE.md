# なでしこ3 データサイエンス機能拡張
# Nadesiko3 Data Science Extension

## 概要 / Overview

Pythonのデータサイエンス機能をなでしこ3に実装しました。NumPy、Pandas、Scikit-Learnのような機能を日本語で利用できます。

Implemented Python-like data science functionality in Nadesiko3. NumPy, Pandas, and Scikit-Learn-like features are available in Japanese.

---

## 🇯🇵 日本語版 / Japanese Version

## 追加されたプラグイン

### 1. plugin_datascience.mts - データ処理（NumPy風）

**配列操作:**
- `配列作成`: 指定サイズの配列を作成
- `ゼロ配列`: ゼロで初期化された配列
- `1配列`: 1で初期化された配列  
- `範囲配列`: 指定範囲の数値配列
- `配列形状`: 配列の形状を取得
- `配列リサイズ`: 配列のサイズ変更
- `配列連結`: 配列の結合

**数学関数:**
- `合計`: 配列の合計値
- `平均`: 配列の平均値
- `最大値`: 配列の最大値
- `最小値`: 配列の最小値
- `標準偏差`: 標準偏差の計算
- `分散`: 分散の計算
- `配列要素積`: 配列要素の積
- `配列累積和`: 累積和の計算

**統計関数:**
- `中央値`: 中央値の計算
- `最頻値`: 最頻値の計算
- `相関係数`: 相関係数の計算

### 2. plugin_statistics.mts - 統計分析

**記述統計:**
- `要約統計量`: 基本統計量のまとめ

**確率分布:**
- `正規分布PDF`: 正規分布の確率密度関数
- `正規分布CDF`: 正規分布の累積分布関数

**仮説検定:**
- `t検定`: t検定の実行
- `カイ二乗検定`: カイ二乗検定の実行

**相関分析:**
- `ピアソン相関`: ピアソンの相関係数
- `スピアマン相関`: スピアマンの順位相関係数

**回帰分析:**
- `単回帰分析`: 単回帰分析の実行

**分散分析:**
- `一元配置分散分析`: 一元配置分散分析の実行

### 3. plugin_machinelearning.mts - 機械学習

**データ前処理:**
- `データ正規化`: データの正規化（0-1範囲）
- `データ標準化`: データの標準化（平均0、分散1）
- `訓練テスト分割`: データを訓練用とテスト用に分割

**教師あり学習:**
- `線形回帰学習`: 線形回帰モデルの学習
- `線形回帰予測`: 線形回帰による予測
- `K近傍法分類`: K近傍法による分類
- `決定木分類`: 単純な決定木による分類
- `パーセプトロン学習`: 単純パーセプトロンの学習

**教師なし学習:**
- `K平均法クラスタリング`: K平均法によるクラスタリング

**評価指標:**
- `平均二乗誤差`: MSEの計算
- `平均絶対誤差`: MAEの計算
- `正解率`: 分類の正解率

## 使用例

### 基本的なデータ処理

```nako3
# データの作成
データ = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# 基本統計量
「平均: {データの平均}」と表示
「標準偏差: {データの標準偏差}」と表示
「中央値: {データの中央値}」と表示

# 相関分析
X = [1, 2, 3, 4, 5]
Y = [2, 4, 6, 8, 10]
相関 = XとYの相関係数
「相関係数: {相関}」と表示
```

### 機械学習

```nako3
# 線形回帰
訓練X = [1, 2, 3, 4, 5]
訓練Y = [2, 4, 6, 8, 10]
モデル = 訓練Xで訓練Yを線形回帰学習

# 予測
テストデータ = [6, 7, 8]
予測結果 = モデルでテストデータを線形回帰予測
「予測結果: {予測結果}」と表示

# 評価
実際値 = [12, 14, 16]
MSE = 実際値と予測結果の平均二乗誤差
「平均二乗誤差: {MSE}」と表示
```

### 分類

```nako3
# K近傍法分類
特徴量 = [1.0, 1.5, 2.0, 2.5, 3.0]
ラベル = ["A", "A", "B", "B", "C"]
テスト特徴量 = [1.2, 2.8]

分類結果 = 特徴量とラベルでテスト特徴量を3のK近傍法分類
「分類結果: {分類結果}」と表示
```

## デモプログラム

`demo/datascience_demo.nako3` にすべての機能を実演するデモプログラムがあります。

```bash
cnako3 demo/datascience_demo.nako3
```

## Pythonとの比較

| 機能 | Python | なでしこ3 |
|------|--------|------------|
| 配列作成 | np.array() | 配列作成 |
| 平均値 | np.mean() | 平均 |
| 標準偏差 | np.std() | 標準偏差 |
| 相関係数 | np.corrcoef() | 相関係数 |
| 線形回帰 | sklearn.linear_model | 線形回帰学習 |
| K近傍法 | sklearn.neighbors | K近傍法分類 |
| クラスタリング | sklearn.cluster | K平均法クラスタリング |

## 今後の拡張予定

- 時系列分析機能
- ディープラーニング基本機能
- 自然言語処理機能
- 画像処理機能
- より高度な機械学習アルゴリズム

## 注意事項

- 現在の実装は教育・学習用を目的としています
- 本格的なデータサイエンス用途にはPythonのライブラリを使用することを推奨します

---

## 🇺🇸 English Version

## Usage Examples

### Basic Array Operations
```nako3
# Load plugin
!「plugin_datascience.mjs」を取り込む。

# Create arrays
zeros = 5のゼロ配列    # [0,0,0,0,0]
ones = 4の配列1埋      # [1,1,1,1]
range = 1から5まで範囲配列  # [1,2,3,4,5]

# Statistical calculations
data = [1,2,3,4,5]
mean = dataの平均        # 3
std = dataの標準偏差     # 1.414...
correlation = [1,2,3]と[2,4,6]の相関係数  # 1.0
```

### Advanced Analysis
```nako3
# Regression analysis
X = [1,2,3,4,5]
Y = [2,4,6,8,10]
model = XとYで回帰直線
slope = model["slope"]      # 2.0
intercept = model["intercept"]  # 0.0

# Prediction
new_x = 6
predicted_y = slope * new_x + intercept  # 12.0
```

## Testing

Run the data science tests:
```bash
npm run test:datascience
```

Run the demos:
```bash
npm run demo:datascience
node src/cnako3.mjs demo/datascience_demo_manual.nako3  # Japanese
node src/cnako3.mjs demo/datascience_demo_en.nako3      # English
```

## Features

✅ **22 test cases passing**
✅ **NumPy-like array operations**
✅ **Statistical functions**
✅ **Machine learning basics**
✅ **Japanese and English documentation**
✅ **Complete demo examples**

## Performance

- Efficient array operations using JavaScript
- Statistical calculations optimized for speed
- Memory-efficient implementations

## Compatibility

- Node.js environment
- Browser environment (wnako3)
- Compatible with existing Nadesiko3 plugins

## Future Enhancements

- Deep learning support
- Time series analysis
- Natural language processing
- Advanced machine learning algorithms

---

**🚀 Nadesiko3 now has Python-like data science capabilities!**  
**📚 Perfect for education, research, and practical applications!**
- パフォーマンスは最適化されていません

## ライセンス

MIT License - なでしこ3プロジェクトと同じライセンスです。
