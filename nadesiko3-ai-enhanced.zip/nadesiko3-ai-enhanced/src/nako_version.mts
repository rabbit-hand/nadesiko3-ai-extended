/**
 * なでしこのバージョン情報
 * package.json から自動的に作成されます。このファイルを編集しないでください。
 */
// 型定義
export interface NakoVersion {
    version: string;
    major: number;
    minor: number;
    patch: number;
}
// 実際のバージョン定義 (自動生成されるので以下を編集しない)
const nakoVersion: NakoVersion = {
  version: '3.7.19',
  major: 3,
  minor: 7,
  patch: 19
}
export default nakoVersion
